#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){

float h=0.01;
float min_x = 0.0;
float max_x = 3.0;
int n_points = ((max_x-min_x)/h);
float x[n_points];
float w[n_points];
float y[n_points];
float z[n_points];
int sig=10;
float bet=8/3;
int rho=28;
float average_k;
float average_l;
float average_m;
float k1;
float l1;
float m1;
float k2;
float l2;
float m2;
float k3;
float l3;
float m3;
float k4;
float l4;
float m4;
int i =0;
x[0] = min_x;
w[0] = 10*(double) drand48();
y[0] = 10*(double) drand48();
z[0] = 10*(double) drand48();

FILE *pfilex = fopen("xx.txt", "w");
FILE *pfiley = fopen("yy.txt", "w");
FILE *pfilez = fopen("zz.txt", "w");

fprintf(pfilex, "%f \t", w[0]);
fprintf(pfiley, "%f \t", y[0]);
fprintf(pfilez, "%f \t", z[0]);

for (i=1;i<n_points; i++){
    k1 = h * sig*(y[i-1]-w[i-1]);
    l1 = h * w[i-1]*(rho-z[i-1])-y[i-1];
    m1 = h * w[i-1]*y[i-1]-bet*z[i-1];

    k2 = h * sig*((y[i-1]+ 0.5 * l1)-(w[i-1]+ 0.5 * k1));
    l2 = h * (w[i-1]+ 0.5 * k1)*(rho-(z[i-1]+ 0.5 * m1))-(y[i-1]+ 0.5 * l1);
    m2 = h * (w[i-1]+ 0.5 * k1)*(y[i-1]+ 0.5 * l1)-bet*(z[i-1]+ 0.5 * m1);

    k3 = h * sig*((y[i-1]+ 0.5 * l2)-(w[i-1]+ 0.5 * k2));
    l3 = h * (w[i-1]+ 0.5 * k2)*(rho-(z[i-1]+ 0.5 * m2))-(y[i-1]+ 0.5 * l2);
    m3 = h * (w[i-1]+ 0.5 * k2)*(y[i-1]+ 0.5 * l2)-bet*(z[i-1]+ 0.5 * m2);

    k4 = h * sig*((y[i-1]+ l3)-(w[i-1]+ k3));
    l4 = h * (w[i-1]+ k3)*(rho-(z[i-1]+ m3))-(y[i-1]+ l3);
    m4 = h * (w[i-1]+ k3)*(y[i-1]+ l3)-bet*(z[i-1]+ m3);

    //fourth step
    average_k = (1.0/6.0)*(k1 + 2.0*k2 + 2.0*k3 + k4);
    average_l = (1.0/6.0)*(l1 + 2.0*l2 + 2.0*l3 + l4);
    average_m = (1.0/6.0)*(m1 + 2.0*m2 + 2.0*k3 + m4);
    
    x[i] = x[i-1] + h;
    w[i] = w[i-1] + average_k;
    y[i] = y[i-1] + average_l;
    z[i] = z[i-1] + average_m;
 
    fprintf(pfilex, "%f \t", w[i]);
    fprintf(pfiley, "%f \t", y[i]);
    fprintf(pfilez, "%f \t", z[i]);
}

}
